import React, { useEffect, useState } from 'react';

const initialTransactions = [
  { id: 1, name: 'Mrs Reef', amountUSD: 161, amountLBP: '', amountGBP: '', type: 'Out', notes: '' },
  { id: 2, name: 'Sleiman', amountUSD: 115, amountLBP: '', amountGBP: '', type: 'Out', notes: '' },
  { id: 3, name: 'Farouj', amountUSD: 12, amountLBP: '', amountGBP: '', type: 'Out', notes: '' },
  { id: 4, name: 'Baraj', amountUSD: 136, amountLBP: 400000, amountGBP: '', type: 'Out', notes: 'USD + LBP' },
  { id: 5, name: 'Hamoudi', amountUSD: 125, amountLBP: '', amountGBP: '', type: 'Out', notes: '' },
  { id: 6, name: 'Ahmad', amountUSD: 365, amountLBP: '', amountGBP: '', type: 'Out', notes: '' },
  { id: 7, name: 'Vera', amountUSD: 264, amountLBP: '', amountGBP: '', type: 'Out', notes: 'Mira' },
  { id: 8, name: 'Rayan', amountUSD: 83, amountLBP: '', amountGBP: '', type: 'Out', notes: '' },
  { id: 9, name: 'Montaser', amountUSD: 44, amountLBP: '', amountGBP: '', type: 'Out', notes: '' },
  { id: 10, name: 'Vanessa', amountUSD: 1240, amountLBP: '', amountGBP: '', type: 'Out', notes: '' },
];

export default function App() {
  const [transactions, setTransactions] = useState(initialTransactions);
  const [form, setForm] = useState({ name: '', amountUSD: '', amountLBP: '', amountGBP: '', type: 'Out', notes: '' });
  const [rates, setRates] = useState({ USD: 1, LBP: null, GBP: null, fetchedAt: null });
  const [selectedCurrency, setSelectedCurrency] = useState('USD');

  useEffect(() => {
    let mounted = true;
    async function fetchRates() {
      try {
        const res = await fetch('https://api.exchangerate.host/latest?base=USD&symbols=LBP,GBP');
        const data = await res.json();
        if (!mounted) return;
        setRates({ USD: 1, LBP: data.rates.LBP, GBP: data.rates.GBP, fetchedAt: Date.now() });
      } catch (err) {
        console.error('FX fetch failed', err);
      }
    }
    fetchRates();
    const id = setInterval(fetchRates, 300000); // 5 minutes
    return () => { mounted = false; clearInterval(id); };
  }, []);

  const addTransaction = () => {
    if (!form.name) return;
    if (!form.amountUSD && !form.amountLBP && !form.amountGBP) return;
    setTransactions(prev => [...prev, { ...form, id: Date.now() }]);
    setForm({ name: '', amountUSD: '', amountLBP: '', amountGBP: '', type: 'Out', notes: '' });
  };

  const parseNum = (v) => v === '' || v === null ? 0 : Number(v);

  const totalsRaw = transactions.reduce((acc, t) => {
    acc.USD += parseNum(t.amountUSD) * (t.type === 'In' ? 1 : -1);
    acc.LBP += parseNum(t.amountLBP) * (t.type === 'In' ? 1 : -1);
    acc.GBP += parseNum(t.amountGBP) * (t.type === 'In' ? 1 : -1);
    return acc;
  }, { USD: 0, LBP: 0, GBP: 0 });

  // Conversion helpers
  // rates: 1 USD = rates.LBP LBP ; 1 USD = rates.GBP GBP
  const toUSD = (t) => {
    const usdFromUSD = parseNum(t.amountUSD);
    const usdFromLBP = parseNum(t.amountLBP) && rates.LBP ? parseNum(t.amountLBP) / rates.LBP : 0;
    const usdFromGBP = parseNum(t.amountGBP) && rates.GBP ? parseNum(t.amountGBP) / rates.GBP : 0;
    const sign = t.type === 'In' ? 1 : -1;
    return sign * (usdFromUSD + usdFromLBP + usdFromGBP);
  };

  const toSelected = (t) => {
    if (!rates.LBP || !rates.GBP) return 0;
    const usd = toUSD(t); // in USD
    if (selectedCurrency === 'USD') return usd;
    if (selectedCurrency === 'GBP') return usd * rates.GBP; // USD -> GBP
    return usd;
  };

  const totalSelected = transactions.reduce((acc, t) => acc + toSelected(t), 0);

  return (
    <div style={{ fontFamily: 'system-ui, Arial', padding: 20, background: '#f3f4f6', minHeight: '100vh' }}>
      <div style={{ maxWidth: 900, margin: '0 auto' }}>
        <h1 style={{ fontSize: 28, marginBottom: 10 }}>💵 Spending Tracker</h1>

        <div style={{ background: '#fff', padding: 16, borderRadius: 12, marginBottom: 16 }}>
          <h2 style={{ marginTop: 0 }}>Add Transaction</h2>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8 }}>
            <input placeholder="Name" value={form.name} onChange={e=>setForm({...form,name:e.target.value})} />
            <input placeholder="Amount (USD)" value={form.amountUSD} onChange={e=>setForm({...form,amountUSD:e.target.value})} />
            <input placeholder="Amount (LBP)" value={form.amountLBP} onChange={e=>setForm({...form,amountLBP:e.target.value})} />
            <input placeholder="Amount (GBP)" value={form.amountGBP} onChange={e=>setForm({...form,amountGBP:e.target.value})} />
            <select value={form.type} onChange={e=>setForm({...form,type:e.target.value})}>
              <option>Out</option>
              <option>In</option>
            </select>
            <input placeholder="Notes" value={form.notes} onChange={e=>setForm({...form,notes:e.target.value})} />
          </div>
          <div style={{ marginTop: 8 }}>
            <button onClick={addTransaction} style={{ padding: '8px 12px', borderRadius: 8, background: '#2563eb', color: '#fff', border: 'none' }}>➕ Add</button>
          </div>
        </div>

        <div style={{ background: '#fff', padding: 16, borderRadius: 12 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <h2 style={{ margin: 0 }}>Transactions</h2>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
              <label style={{ fontSize: 14 }}>Main display:</label>
              <select value={selectedCurrency} onChange={e=>setSelectedCurrency(e.target.value)}>
                <option value="USD">USD</option>
                <option value="GBP">GBP</option>
              </select>
            </div>
          </div>

          <table style={{ width: '100%', marginTop: 12, borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ textAlign: 'left', borderBottom: '1px solid #e5e7eb' }}>
                <th style={{ padding: 8 }}>Name</th>
                <th>USD</th>
                <th>LBP</th>
                <th>GBP</th>
                <th>Type</th>
                <th>Notes</th>
              </tr>
            </thead>
            <tbody>
              {transactions.map(t => (
                <tr key={t.id} style={{ borderBottom: '1px solid #f3f4f6' }}>
                  <td style={{ padding: 8 }}>{t.name}</td>
                  <td>{t.amountUSD || '-'}</td>
                  <td>{t.amountLBP || '-'}</td>
                  <td>{t.amountGBP || '-'}</td>
                  <td>{t.type}</td>
                  <td>{t.notes}</td>
                </tr>
              ))}
            </tbody>
          </table>

          <div style={{ marginTop: 12 }}>
            <div><strong>Raw totals:</strong></div>
            <div>USD: {totalsRaw.USD}</div>
            <div>LBP: {totalsRaw.LBP}</div>
            <div>GBP: {totalsRaw.GBP}</div>

            <div style={{ marginTop: 8 }}>
              <strong>Main total ({selectedCurrency}):</strong> {Number(totalSelected.toFixed(2))}
            </div>

            <div style={{ marginTop: 8, fontSize: 13, color: '#6b7280' }}>
              {rates.LBP ? (
                <>
                  <div>FX rates (base USD): 1 USD = {rates.LBP.toLocaleString()} LBP, {rates.GBP.toFixed(4)} GBP</div>
                  <div>Rates auto-refresh every 5 minutes. Fetched at: {rates.fetchedAt ? new Date(rates.fetchedAt).toLocaleString() : '—'}</div>
                </>
              ) : <div>Fetching FX rates…</div>}
            </div>
          </div>
        </div>

        <div style={{ marginTop: 12, fontSize: 13, color: '#6b7280' }}>
          <strong>How it works:</strong> Enter amounts in USD, LBP or GBP. Choose the main display currency (USD or GBP) to see a unified balance — all amounts will be converted using live FX rates.
        </div>
      </div>
    </div>
  );
}
