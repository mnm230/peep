# Spending Tracker - Ready to Deploy

This is a minimal Vite + React app that tracks transactions in USD, LBP (Lebanese Pounds), and GBP.
Features:
- Enter amounts in USD, LBP, and GBP.
- See raw totals per currency.
- Choose a main display currency (USD or GBP) — all amounts are converted using live FX rates from exchangerate.host.
- FX rates auto-refresh every 5 minutes.

## Quick deploy (Vercel - upload ZIP)
1. Download the ZIP file included with this package.
2. Go to https://vercel.com/new and choose **Import Project -> Upload**.
3. Upload the ZIP file. Vercel will detect a Vite project and deploy it.
4. After a few moments you'll get a live link.

## Run locally
```bash
npm install
npm run dev
```

API used: https://api.exchangerate.host (no API key required)
